package RestAssured.Assignment_LPB12;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import RestAssured.Assignment_LPB12.fetchfromexcel;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


import java.io.IOException;
//import org.apache.commons.io.IOUtils;
import static org.hamcrest.Matchers.*;

public class Restassuredtestcase1 {
	
	@Test(enabled = false)
	public void postmethod(){
		
		RestAssured.baseURI ="http://localhost:3000/";
		String reqbody = "{\"stream\":\"art\",\"firstname\":\"Neha\",\"lastname\":\"sharma\"}";
		
		given()
			.headers("Content-Type","Application/JSON")
			.body(reqbody).
		when()
			.post("students").
		then()
		     .statusCode(201).log().all();
	}
	
	@Test(enabled = false)
	public void jsonbody() {

		RestAssured.baseURI = "http://localhost:3000/";
		JSONObject rootbodyobject = new JSONObject();
		JSONObject categoryobject = new JSONObject();
		JSONObject tagsobject = new JSONObject();
		rootbodyobject.put("id", 0);
		rootbodyobject.put("name", "Neha");
		rootbodyobject.put("status", "available");

		String name = "Sonam";
		categoryobject.put("id", 0);
		categoryobject.put("name", "abcd");

		tagsobject.put("id", 0);
		tagsobject.put("name", name);

		// Adding the Category and Tags object into the Rootbody
		rootbodyobject.put("category", categoryobject);
		rootbodyobject.put("tags", tagsobject);

		// JSON Array Body
		JSONArray arraybody = new JSONArray();
		arraybody.add("abc");
		arraybody.add("values1");

		// Adding the Arrayobject into Root body
		rootbodyobject.put("photoUrls", arraybody);

		System.out.println(rootbodyobject);

		
	}

	@Test(enabled = false, dataProvider = "fetchfromexcel")
	public void datasourceexample(String firstname, String lastname, String art) {
		RestAssured.baseURI = "http://localhost:3000/";
		JSONObject rootbodyobject = new JSONObject();

		rootbodyobject.put("firstname", firstname);
		rootbodyobject.put("lastname", lastname);
		rootbodyobject.put("stream", art);

		given().body(rootbodyobject.toJSONString()).headers("content-type", "Application/JSON").when().post("students")
				.then().log().all();

	}

	@DataProvider(name = "TestSample")
	public Object[][] data() {
		Object[][] data = new Object[2][3];
		data[0][0] = "Neha";
		data[0][1] = "Pihu";
		data[0][2] = "Tinu";
		data[1][0] = "Teena";
		data[1][1] = "kiara";
		data[1][2] = "Shilpa";

		return data;

	}

	@DataProvider(name = "fetchfromexcel")
	public Object[][] exceldata() throws IOException {
		Object[][] data = fetchfromexcel.gettestdata();

		return data;

	}
}
